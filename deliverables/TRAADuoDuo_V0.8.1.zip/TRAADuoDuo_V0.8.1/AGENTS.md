# TRAADuoDuo 工作入口與資料安全

使用者於 2026-10-17 再次確認：以後使用 `/Volumes/Photo-Disk/codexP` 新入口。此專案位於 `/Volumes/Photo-Disk/codexP/2026-09-22/x20`。舊 Qoo 路徑不存在時，不以其作為阻擋新入口工作的前提。

- 工作與測試產物放專案 `work/`；獨立版本交付放 `outputs/TRAADuoDuo/Vx.y.z/`。
- 保留舊版與使用者資料；舊資料庫唯讀預覽後匯入新庫，不直接覆寫來源。
- 「同步」僅指雲端；「推送／發布」才授權 GitHub。本機實作不包含這兩項。
- macOS 保留單一執行個體；QA 使用獨立資料與設定，不終止使用者正式程式。
