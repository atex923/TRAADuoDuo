"""TRAADuoDuo V0.6.1 windowed launcher."""
from traaduoduo.app import main

if __name__ == '__main__':
    raise SystemExit(main())
